<h1 align = "center">Merlin Fashion🛒</h1>


<p align="center">Refresh Your Wardrobe!🛍️ 
 <p align="center">
With a passion for fashion here's my very own custom website relating to it.💃
 </p>
 
 
 <p align="center">
 The template is for the Online Clothing Fashion which includes trending wardrobe collection. The website is made from scratch 🥳 and doesn't include any readymade code.
Merlin Fashion doesn't include anything related to database, it is just a HTML, CSS and JS template. Though you can find some familiar images used in the website taken from various sources, but the purpose is to only make it more beautiful.🖤

 </p>

  <p align="center">
    And that's how it looks🤩
 </p>
 <p align="center">
 <img src="https://user-images.githubusercontent.com/47295558/76738138-11372680-6790-11ea-82c6-c27a9c2b7b68.gif">
  </p>
 <p align="center">
 Saw all the other pages?🧐 Go check it out now!🥳 
   https://singh-shivani.github.io/Merlin-Fashion/
</p>
