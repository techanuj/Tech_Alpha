import Homescreen from './views/Homescreen/Homescreen'
import './App.css'

function App() {
  return (
    <div className="App">
      <Homescreen />
    </div>
  );
}

export default App;
