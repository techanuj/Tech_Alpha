# Give a star if you are helped by this repo 🙏

A simple recipe website template, made using simple html, js and css. The website template features a clean and intuitive design, making it easy for users to navigate and find their desired recipes.
[link to website](https://shizu-ka.github.io/Website-Calorie/)

![2022-12-06 (5)](https://user-images.githubusercontent.com/58659139/205823398-e07e2d4a-9150-4d54-aca5-45f9f3e163d4.png)
