# An online education website UI

Made in Nextjs and tailwind css.
